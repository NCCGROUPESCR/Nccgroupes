/* ============================================================
   KUDIESCROW — MOCK DATA STORE
   A self-contained "backend" for the static demo, persisted to
   localStorage. Mirrors the shape the real NestJS API will use
   (see /server/BUILD_PROMPT.md) so wiring a real backend later
   is a drop-in swap of these functions for fetch() calls.
   ============================================================ */

const KE_KEYS = {
  users: 'ke_users',
  session: 'ke_session',
  txns: 'ke_transactions',
  notifs: 'ke_notifications',
  seeded: 'ke_seeded_v1'
};

function ke_read(key, fallback){
  try{
    const raw = localStorage.getItem(key);
    return raw ? JSON.parse(raw) : fallback;
  }catch(e){ return fallback; }
}
function ke_write(key, value){
  localStorage.setItem(key, JSON.stringify(value));
}
function ke_id(prefix){
  return prefix + '-' + Math.random().toString(36).slice(2,8).toUpperCase();
}
function ke_ref(){
  const n = Math.floor(100000 + Math.random()*900000);
  return 'KE-' + new Date().getFullYear() + '-' + n;
}
function ke_now(){ return new Date().toISOString(); }

/* ---------------- SEED ---------------- */
function ke_seed(){
  if (ke_read(KE_KEYS.seeded, false)) return;

  const users = [
    { id:'U-BUYER1', name:'Amara Chukwu', email:'amara@buyer.demo', password:'demo1234', role:'buyer', trust:96, avatarInitial:'A', createdAt: ke_now() },
    { id:'U-SELLER1', name:'Tunde Okafor — Okafor Textiles Ltd', email:'tunde@seller.demo', password:'demo1234', role:'seller', trust:88, verified:true, avatarInitial:'T', createdAt: ke_now() },
    { id:'U-LOG1', name:'SwiftRoute Logistics', email:'ops@swiftroute.demo', password:'demo1234', role:'logistics', trust:91, avatarInitial:'S', createdAt: ke_now() },
    { id:'U-SUPPORT1', name:'Ngozi Bello', email:'ngozi@kudiescrow.demo', password:'demo1234', role:'support', avatarInitial:'N', createdAt: ke_now() },
    { id:'U-ADMIN1', name:'Platform Admin', email:'admin@kudiescrow.demo', password:'demo1234', role:'admin', avatarInitial:'K', createdAt: ke_now() },
    { id:'U-DEV1', name:'Chidi Obi', email:'chidi@developer.demo', password:'demo1234', role:'developer', avatarInitial:'C', createdAt: ke_now() },
  ];
  ke_write(KE_KEYS.users, users);

  const t1 = {
    id: ke_id('TXN'), ref: 'KE-2026-483920',
    title: 'Industrial Sewing Machines (x12) — Lagos to Accra',
    category: 'Manufacturing Equipment',
    buyerId: 'U-BUYER1', sellerId: 'U-SELLER1', logisticsId: 'U-LOG1',
    amount: 4820000, currency: 'NGN',
    status: 'transit',
    createdAt: '2026-06-18T09:12:00Z',
    escrow: { funded:true, fundedAt:'2026-06-18T09:20:00Z', releaseConditions:'Funds release on confirmed delivery + 48hr buyer inspection window.' },
    shipment: {
      mode:'road', origin:'Lagos, Nigeria', destination:'Accra, Ghana', eta:'2026-07-09',
      checkpoints:[
        {label:'Pickup confirmed — Lagos warehouse', status:'done', time:'2026-06-19T08:00:00Z'},
        {label:'Departed origin hub', status:'done', time:'2026-06-19T14:30:00Z'},
        {label:'Customs clearance — Seme border', status:'done', time:'2026-06-21T11:00:00Z'},
        {label:'In transit — Accra corridor', status:'active', time:'2026-07-02T10:00:00Z'},
        {label:'Arrival at destination hub', status:'pending', time:null},
        {label:'Delivered to buyer', status:'pending', time:null},
      ]
    },
    chat: [
      { id: ke_id('MSG'), senderId:'system', type:'system', text:'Transaction created. Escrow reference KE-2026-483920.', time:'2026-06-18T09:12:00Z' },
      { id: ke_id('MSG'), senderId:'U-BUYER1', type:'text', text:'Funds are in escrow. Please confirm pickup window with SwiftRoute.', time:'2026-06-18T09:25:00Z' },
      { id: ke_id('MSG'), senderId:'U-SELLER1', type:'text', text:'Confirmed — pickup scheduled for the 19th, crates are palletized and ready.', time:'2026-06-18T10:02:00Z' },
      { id: ke_id('MSG'), senderId:'U-LOG1', type:'text', text:'Driver assigned. ETA to Accra hub is July 9th, tracking is live on your dashboard.', time:'2026-06-19T08:10:00Z' },
    ],
    dispute: null
  };

  const t2 = {
    id: ke_id('TXN'), ref: 'KE-2026-119004',
    title: 'Handmade Ankara Fabric Bundle (200 yards)',
    category: 'Textiles',
    buyerId: 'U-BUYER1', sellerId: 'U-SELLER1', logisticsId: 'U-LOG1',
    amount: 610000, currency: 'NGN',
    status: 'dispute',
    createdAt: '2026-06-24T13:00:00Z',
    escrow: { funded:true, fundedAt:'2026-06-24T13:05:00Z', releaseConditions:'Funds release on confirmed delivery matching listed specification.' },
    shipment: {
      mode:'road', origin:'Abeokuta, Nigeria', destination:'Lagos, Nigeria', eta:'2026-06-27',
      checkpoints:[
        {label:'Pickup confirmed', status:'done', time:'2026-06-25T09:00:00Z'},
        {label:'Delivered to buyer', status:'done', time:'2026-06-27T15:40:00Z'},
      ]
    },
    chat: [
      { id: ke_id('MSG'), senderId:'system', type:'system', text:'Transaction created. Escrow reference KE-2026-119004.', time:'2026-06-24T13:00:00Z' },
      { id: ke_id('MSG'), senderId:'U-BUYER1', type:'text', text:'Package arrived but the fabric colour and weight do not match the listing photos.', time:'2026-06-27T16:10:00Z' },
      { id: ke_id('MSG'), senderId:'U-SELLER1', type:'text', text:'That is the exact batch shown, dye lots can vary slightly but it is the same grade.', time:'2026-06-27T17:02:00Z' },
      { id: ke_id('MSG'), senderId:'U-BUYER1', type:'text', text:'I would like support to review before funds are released.', time:'2026-06-27T17:10:00Z' },
      { id: ke_id('MSG'), senderId:'system', type:'system', text:'Dispute opened by buyer. Escrow funds frozen. Support has joined this conversation.', time:'2026-06-27T17:11:00Z' },
      { id: ke_id('MSG'), senderId:'U-SUPPORT1', type:'text', text:'Thanks both — I have frozen the release. Buyer, please upload photos of the received fabric next to the original listing for comparison.', time:'2026-06-27T18:30:00Z' },
    ],
    dispute: { opened:true, openedAt:'2026-06-27T17:11:00Z', openedBy:'U-BUYER1', reason:'Item does not match listing description', status:'investigating', assignedAgent:'U-SUPPORT1', notes:[
      {author:'U-SUPPORT1', text:'Requested comparison photos from buyer. Awaiting response before recommending settlement split.', time:'2026-06-27T18:31:00Z'}
    ]}
  };

  const t3 = {
    id: ke_id('TXN'), ref: 'KE-2026-720117',
    title: 'Refurbished MacBook Pro 14" (x5 units)',
    category: 'Electronics',
    buyerId: 'U-BUYER1', sellerId: 'U-SELLER1', logisticsId: 'U-LOG1',
    amount: 3150000, currency: 'NGN',
    status: 'pending',
    createdAt: '2026-07-03T11:00:00Z',
    escrow: { funded:false, fundedAt:null, releaseConditions:'Funds release on confirmed delivery + 24hr inspection window.' },
    shipment: { mode:'air', origin:'Lagos, Nigeria', destination:'Nairobi, Kenya', eta:'2026-07-14', checkpoints:[
      {label:'Awaiting escrow funding', status:'active', time:null},
      {label:'Pickup request', status:'pending', time:null},
      {label:'Departure', status:'pending', time:null},
      {label:'Customs clearance', status:'pending', time:null},
      {label:'Delivered', status:'pending', time:null},
    ]},
    chat: [
      { id: ke_id('MSG'), senderId:'system', type:'system', text:'Transaction created. Awaiting buyer to fund escrow.', time:'2026-07-03T11:00:00Z' },
    ],
    dispute: null
  };

  const t4 = {
    id: ke_id('TXN'), ref: 'KE-2026-055881',
    title: 'Cocoa Beans — Bulk Export Lot (2 tonnes)',
    category: 'Agriculture Export',
    buyerId: 'U-BUYER1', sellerId: 'U-SELLER1', logisticsId: 'U-LOG1',
    amount: 9200000, currency: 'NGN',
    status: 'released',
    createdAt: '2026-05-30T08:00:00Z',
    escrow: { funded:true, fundedAt:'2026-05-30T08:10:00Z', releasedAt:'2026-06-10T09:00:00Z', releaseConditions:'Funds release on confirmed delivery.' },
    shipment: { mode:'sea', origin:'Lagos Port, Nigeria', destination:'Rotterdam, Netherlands', eta:'2026-06-09', checkpoints:[
      {label:'Pickup confirmed', status:'done', time:'2026-05-31T08:00:00Z'},
      {label:'Loaded — Lagos Port', status:'done', time:'2026-06-01T12:00:00Z'},
      {label:'Departed port', status:'done', time:'2026-06-02T06:00:00Z'},
      {label:'Customs clearance — Rotterdam', status:'done', time:'2026-06-08T09:00:00Z'},
      {label:'Delivered to buyer', status:'done', time:'2026-06-09T15:00:00Z'},
    ]},
    chat: [
      { id: ke_id('MSG'), senderId:'system', type:'system', text:'Transaction created. Escrow reference KE-2026-055881.', time:'2026-05-30T08:00:00Z' },
      { id: ke_id('MSG'), senderId:'U-BUYER1', type:'text', text:'Delivery confirmed, quality matches sample. Releasing funds.', time:'2026-06-09T16:00:00Z' },
      { id: ke_id('MSG'), senderId:'system', type:'system', text:'Escrow released to seller. Transaction complete.', time:'2026-06-10T09:00:00Z' },
    ],
    dispute: null
  };

  ke_write(KE_KEYS.txns, [t1,t2,t3,t4]);
  ke_write(KE_KEYS.notifs, [
    { id: ke_id('NOTE'), userId:'U-BUYER1', text:'SwiftRoute Logistics updated tracking for KE-2026-483920.', time:'2026-07-02T10:00:00Z', read:false },
    { id: ke_id('NOTE'), userId:'U-BUYER1', text:'Support joined the dispute on KE-2026-119004.', time:'2026-06-27T17:11:00Z', read:false },
    { id: ke_id('NOTE'), userId:'U-SELLER1', text:'Buyer funded escrow for KE-2026-483920.', time:'2026-06-18T09:20:00Z', read:true },
  ]);

  ke_write(KE_KEYS.seeded, true);
}
ke_seed();

/* ---------------- USERS ---------------- */
function ke_getUsers(){ return ke_read(KE_KEYS.users, []); }
function ke_findUserByEmail(email){ return ke_getUsers().find(u => u.email.toLowerCase() === String(email).toLowerCase()); }
function ke_getUser(id){ return ke_getUsers().find(u => u.id === id); }
function ke_createUser(user){
  const users = ke_getUsers();
  const record = Object.assign({ id: ke_id('U'), trust:70, createdAt: ke_now(), avatarInitial: (user.name||'?').trim().charAt(0).toUpperCase() }, user);
  users.push(record);
  ke_write(KE_KEYS.users, users);
  return record;
}

/* ---------------- SESSION ---------------- */
function ke_login(userId){ ke_write(KE_KEYS.session, { userId, at: ke_now() }); }
function ke_logout(){ localStorage.removeItem(KE_KEYS.session); }
function ke_currentUser(){
  const s = ke_read(KE_KEYS.session, null);
  if (!s) return null;
  return ke_getUser(s.userId) || null;
}
function ke_requireAuth(allowedRoles){
  const u = ke_currentUser();
  if (!u || (allowedRoles && !allowedRoles.includes(u.role))){
    window.location.href = 'login.html';
    return null;
  }
  return u;
}

/* ---------------- TRANSACTIONS ---------------- */
function ke_getTxns(){ return ke_read(KE_KEYS.txns, []); }
function ke_getTxn(id){ return ke_getTxns().find(t => t.id === id); }
function ke_getTxnByRef(ref){ return ke_getTxns().find(t => t.ref === ref); }
function ke_saveTxn(txn){
  const all = ke_getTxns();
  const idx = all.findIndex(t => t.id === txn.id);
  if (idx > -1) all[idx] = txn; else all.push(txn);
  ke_write(KE_KEYS.txns, all);
}
function ke_txnsForUser(user){
  const all = ke_getTxns();
  if (user.role === 'buyer') return all.filter(t => t.buyerId === user.id);
  if (user.role === 'seller') return all.filter(t => t.sellerId === user.id);
  if (user.role === 'logistics') return all.filter(t => t.logisticsId === user.id);
  if (user.role === 'support' || user.role === 'admin') return all;
  return [];
}
function ke_createTxn(data){
  const txn = Object.assign({
    id: ke_id('TXN'), ref: ke_ref(), createdAt: ke_now(), status:'pending',
    escrow:{ funded:false, releaseConditions: data.releaseConditions || 'Funds release on confirmed delivery.' },
    shipment:{ mode:data.mode||'road', origin:data.origin||'', destination:data.destination||'', eta:data.eta||'', checkpoints:[
      { label:'Awaiting escrow funding', status:'active', time:null }
    ]},
    chat:[ { id: ke_id('MSG'), senderId:'system', type:'system', text:'Transaction created. Awaiting buyer to fund escrow.', time: ke_now() } ],
    dispute: null
  }, data);
  ke_saveTxn(txn);
  return txn;
}
function ke_addMessage(txnId, senderId, text, type){
  const txn = ke_getTxn(txnId);
  if (!txn) return;
  txn.chat.push({ id: ke_id('MSG'), senderId, type: type||'text', text, time: ke_now() });
  ke_saveTxn(txn);
  return txn;
}
function ke_fundEscrow(txnId){
  const txn = ke_getTxn(txnId);
  if (!txn) return;
  txn.escrow.funded = true;
  txn.escrow.fundedAt = ke_now();
  txn.status = 'secured';
  txn.shipment.checkpoints[0] = { label:'Escrow funded — awaiting pickup', status:'done', time: ke_now() };
  txn.shipment.checkpoints.push({ label:'Pickup request', status:'active', time:null });
  ke_addMessage(txnId, 'system', 'Buyer funded escrow. Funds are held securely until delivery is confirmed.', 'system');
  ke_saveTxn(txn);
  return txn;
}
function ke_releaseEscrow(txnId, actorId){
  const txn = ke_getTxn(txnId);
  if (!txn) return;
  txn.status = 'released';
  txn.escrow.releasedAt = ke_now();
  ke_addMessage(txnId, 'system', 'Escrow released to seller. Transaction complete.', 'system');
  ke_saveTxn(txn);
  return txn;
}
function ke_refundBuyer(txnId){
  const txn = ke_getTxn(txnId);
  if (!txn) return;
  txn.status = 'refunded';
  ke_addMessage(txnId, 'system', 'Escrow refunded in full to buyer.', 'system');
  ke_saveTxn(txn);
  return txn;
}
function ke_partialSettlement(txnId, buyerPct){
  const txn = ke_getTxn(txnId);
  if (!txn) return;
  txn.status = 'released';
  txn.escrow.releasedAt = ke_now();
  txn.escrow.settlement = { buyerPct, sellerPct: 100-buyerPct };
  ke_addMessage(txnId, 'system', `Partial settlement applied: ${buyerPct}% refunded to buyer, ${100-buyerPct}% released to seller.`, 'system');
  ke_saveTxn(txn);
  return txn;
}
function ke_openDispute(txnId, openedBy, reason){
  const txn = ke_getTxn(txnId);
  if (!txn) return;
  txn.status = 'dispute';
  txn.dispute = { opened:true, openedAt: ke_now(), openedBy, reason, status:'investigating', assignedAgent:null, notes:[] };
  ke_addMessage(txnId, 'system', 'Dispute opened. Escrow funds frozen. Support will join this conversation shortly.', 'system');
  ke_saveTxn(txn);
  return txn;
}
function ke_closeDispute(txnId, resolution){
  const txn = ke_getTxn(txnId);
  if (!txn || !txn.dispute) return;
  txn.dispute.status = 'closed';
  txn.dispute.resolution = resolution;
  ke_saveTxn(txn);
  return txn;
}
function ke_advanceShipment(txnId){
  const txn = ke_getTxn(txnId);
  if (!txn) return;
  const cps = txn.shipment.checkpoints;
  const activeIdx = cps.findIndex(c => c.status === 'active');
  if (activeIdx > -1){
    cps[activeIdx].status = 'done';
    cps[activeIdx].time = ke_now();
    if (cps[activeIdx+1]){ cps[activeIdx+1].status = 'active'; }
    else { txn.status = 'delivered'; }
  }
  if (cps[cps.length-1].status === 'done'){ txn.status = 'delivered'; }
  ke_addMessage(txnId, 'system', `Shipment update: ${cps[activeIdx] ? cps[activeIdx].label : 'progressed'}.`, 'system');
  ke_saveTxn(txn);
  return txn;
}

/* ---------------- NOTIFICATIONS ---------------- */
function ke_notifsForUser(userId){ return ke_read(KE_KEYS.notifs, []).filter(n => n.userId === userId); }
function ke_addNotif(userId, text){
  const all = ke_read(KE_KEYS.notifs, []);
  all.unshift({ id: ke_id('NOTE'), userId, text, time: ke_now(), read:false });
  ke_write(KE_KEYS.notifs, all);
}

/* ---------------- FORMAT HELPERS ---------------- */
function ke_money(amount, currency){
  currency = currency || 'NGN';
  const symbol = currency === 'NGN' ? '₦' : (currency === 'USD' ? '$' : currency + ' ');
  return symbol + Number(amount).toLocaleString('en-NG');
}
function ke_date(iso){
  if (!iso) return '—';
  const d = new Date(iso);
  return d.toLocaleDateString('en-GB', { day:'2-digit', month:'short', year:'numeric' });
}
function ke_datetime(iso){
  if (!iso) return '—';
  const d = new Date(iso);
  return d.toLocaleDateString('en-GB', { day:'2-digit', month:'short' }) + ' · ' + d.toLocaleTimeString('en-GB', { hour:'2-digit', minute:'2-digit' });
}
function ke_relTime(iso){
  if (!iso) return '—';
  const diff = (Date.now() - new Date(iso).getTime())/1000;
  if (diff < 60) return 'just now';
  if (diff < 3600) return Math.floor(diff/60) + 'm ago';
  if (diff < 86400) return Math.floor(diff/3600) + 'h ago';
  return Math.floor(diff/86400) + 'd ago';
}
function ke_statusLabel(status){
  const map = { pending:'Pending funding', secured:'Escrow secured', transit:'In transit', delivered:'Delivered', dispute:'In dispute', released:'Funds released', refunded:'Refunded' };
  return map[status] || status;
}
