/* ============================================================
   KUDIESCROW — SHARED UI BEHAVIOR
   ============================================================ */

function ke_toast(msg, ms){
  let el = document.getElementById('ke-toast');
  if (!el){
    el = document.createElement('div');
    el.id = 'ke-toast';
    el.className = 'toast';
    document.body.appendChild(el);
  }
  el.textContent = msg;
  el.classList.add('show');
  clearTimeout(el._t);
  el._t = setTimeout(() => el.classList.remove('show'), ms || 3200);
}

function ke_initMobileNav(){
  const toggle = document.querySelector('.nav-toggle');
  const links = document.querySelector('.nav-links');
  if (!toggle || !links) return;
  toggle.addEventListener('click', () => {
    const open = links.style.display === 'flex';
    links.style.display = open ? 'none' : 'flex';
    links.style.flexDirection = 'column';
    links.style.position = 'absolute';
    links.style.top = '76px';
    links.style.left = '0'; links.style.right = '0';
    links.style.background = 'var(--paper)';
    links.style.borderBottom = '1.5px solid var(--line)';
    links.style.padding = '1rem 1.5rem';
    links.style.gap = '1rem';
  });
}

const KE_NAV_BY_ROLE = {
  buyer: [
    { label:'Overview', href:'dashboard-buyer.html', icon:'grid' },
    { label:'Transactions', href:'dashboard-buyer.html#transactions', icon:'list' },
    { label:'New transaction', href:'new-transaction.html', icon:'plus' },
    { label:'Tracking', href:'tracking.html', icon:'route' },
    { label:'Wallet', href:'dashboard-buyer.html#wallet', icon:'wallet' },
  ],
  seller: [
    { label:'Overview', href:'dashboard-seller.html', icon:'grid' },
    { label:'Transactions', href:'dashboard-seller.html#transactions', icon:'list' },
    { label:'Tracking', href:'tracking.html', icon:'route' },
    { label:'Wallet', href:'dashboard-seller.html#wallet', icon:'wallet' },
    { label:'Trust score', href:'dashboard-seller.html#trust', icon:'star' },
  ],
  logistics: [
    { label:'Overview', href:'dashboard-logistics.html', icon:'grid' },
    { label:'Shipments', href:'dashboard-logistics.html#shipments', icon:'truck' },
    { label:'Tracking', href:'tracking.html', icon:'route' },
    { label:'Earnings', href:'dashboard-logistics.html#earnings', icon:'wallet' },
  ],
  support: [
    { label:'Overview', href:'dashboard-support.html', icon:'grid' },
    { label:'Disputes', href:'dashboard-support.html#disputes', icon:'flag' },
    { label:'All transactions', href:'dashboard-support.html#transactions', icon:'list' },
  ],
  admin: [
    { label:'Overview', href:'dashboard-support.html', icon:'grid' },
    { label:'Disputes', href:'dashboard-support.html#disputes', icon:'flag' },
    { label:'All transactions', href:'dashboard-support.html#transactions', icon:'list' },
    { label:'Users', href:'dashboard-support.html#users', icon:'users' },
    { label:'Platform settings', href:'dashboard-support.html#settings', icon:'settings' },
  ],
  developer: [
    { label:'Overview', href:'developer.html', icon:'grid' },
    { label:'API keys', href:'developer.html#keys', icon:'key' },
    { label:'Webhooks', href:'developer.html#webhooks', icon:'webhook' },
    { label:'Documentation', href:'developer.html#docs', icon:'book' },
  ]
};

function ke_icon(name){
  const icons = {
    grid: '<rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/>',
    list: '<line x1="8" y1="6" x2="21" y2="6"/><line x1="8" y1="12" x2="21" y2="12"/><line x1="8" y1="18" x2="21" y2="18"/><line x1="3" y1="6" x2="3.01" y2="6"/><line x1="3" y1="12" x2="3.01" y2="12"/><line x1="3" y1="18" x2="3.01" y2="18"/>',
    plus: '<line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/>',
    route: '<circle cx="6" cy="19" r="2"/><circle cx="18" cy="5" r="2"/><path d="M8.5 19H15a3 3 0 0 0 3-3v-1a3 3 0 0 0-3-3H9a3 3 0 0 1-3-3V8.5"/>',
    wallet: '<rect x="2" y="6" width="20" height="14" rx="1"/><path d="M2 10h20"/><circle cx="17" cy="15" r="1.4"/>',
    star: '<polygon points="12 2 15 9 22 9.5 17 14.5 18.5 22 12 18 5.5 22 7 14.5 2 9.5 9 9"/>',
    truck: '<rect x="1" y="7" width="14" height="10" rx="1"/><path d="M15 10h3l3 3v4h-6"/><circle cx="6" cy="19" r="1.6"/><circle cx="17.5" cy="19" r="1.6"/>',
    flag: '<path d="M5 3v18"/><path d="M5 4h11l-2 4 2 4H5"/>',
    users: '<circle cx="9" cy="8" r="3.2"/><path d="M3.5 19c0-3 2.5-5.2 5.5-5.2s5.5 2.2 5.5 5.2"/><circle cx="17.5" cy="9" r="2.4"/><path d="M15.7 13.6c2.2.3 4 2.2 4 4.6"/>',
    settings: '<circle cx="12" cy="12" r="3"/><path d="M19.4 13a7.6 7.6 0 0 0 0-2l2-1.5-2-3.4-2.3.9a7.4 7.4 0 0 0-1.7-1L15 3h-6l-.4 2.5a7.4 7.4 0 0 0-1.7 1l-2.3-.9-2 3.4L4.6 11a7.6 7.6 0 0 0 0 2l-2 1.5 2 3.4 2.3-.9c.5.4 1.1.7 1.7 1L9 21h6l.4-2.5c.6-.3 1.2-.6 1.7-1l2.3.9 2-3.4-2-1.5z"/>',
    key: '<circle cx="8" cy="15" r="4"/><path d="M11 12l8-8"/><path d="M16 7l2 2"/><path d="M13 10l2 2"/>',
    webhook: '<path d="M6 15a4 4 0 1 1 4-4"/><circle cx="18" cy="7" r="2.4"/><circle cx="6" cy="17.5" r="2.4"/><circle cx="16" cy="17.5" r="2.4"/><path d="M10 11l4.5 5"/><path d="M17 9l-1 6"/>',
    book: '<path d="M4 4.5A2.5 2.5 0 0 1 6.5 2H20v17H6.5A2.5 2.5 0 0 0 4 21.5v-17z"/><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/>'
  };
  return `<svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">${icons[name]||''}</svg>`;
}

function ke_renderShell(user, activeHref){
  const nav = KE_NAV_BY_ROLE[user.role] || [];
  const sideLabel = { buyer:'Buyer', seller:'Seller', logistics:'Logistics', support:'Support', admin:'Administrator', developer:'Developer' }[user.role];
  const sidebar = document.querySelector('.app-sidebar');
  if (sidebar){
    sidebar.innerHTML = `
      <a href="index.html" class="brand">${ke_brandMark()}<span>KudiEscrow</span></a>
      <nav class="side-nav">
        <div class="side-label">${sideLabel}</div>
        ${nav.map(item => `<a href="${item.href}" class="${activeHref===item.href?'active':''}">${ke_icon(item.icon)}<span>${item.label}</span></a>`).join('')}
        <div class="side-label">Account</div>
        <a href="#" id="ke-logout">${ke_icon('settings')}<span>Sign out</span></a>
      </nav>
    `;
  }
  const chip = document.querySelector('.user-chip');
  if (chip){
    chip.innerHTML = `<div class="user-avatar">${user.avatarInitial}</div><div><div style="font-weight:600;">${user.name}</div><div style="color:var(--muted); font-size:0.78rem; text-transform:capitalize;">${user.role} account</div></div>`;
  }
  document.getElementById('ke-logout')?.addEventListener('click', (e) => { e.preventDefault(); ke_logout(); window.location.href='login.html'; });
}

function ke_brandMark(){
  return `<svg class="brand-mark" viewBox="0 0 32 32" fill="none"><circle cx="16" cy="16" r="14.5" stroke="currentColor" stroke-width="1.6"/><circle cx="16" cy="16" r="10.5" stroke="currentColor" stroke-width="1.2"/><path d="M11 16.5l3.2 3.2L21.5 12" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>`;
}

function ke_stampClass(status){
  const map = { pending:'stamp-pending', secured:'stamp-secured', transit:'stamp-transit', delivered:'stamp-delivered', dispute:'stamp-dispute', released:'stamp-released', refunded:'stamp-dispute' };
  return map[status] || 'stamp-pending';
}
