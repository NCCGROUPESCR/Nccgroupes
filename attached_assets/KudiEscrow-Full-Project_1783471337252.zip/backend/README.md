# KudiEscrow API

Secure escrow, logistics, and trade-assurance platform backend. NestJS +
PostgreSQL + Redis + Paystack + Socket.IO, built to the spec in
`KudiEscrow-Backend-Build-Prompt.md` and wired to be a drop-in replacement
for the mock data layer (`js/store.js`) in the KudiEscrow frontend.

## Stack

- NestJS 10 (TypeScript), TypeORM 0.3 / PostgreSQL 15
- Redis 7 — BullMQ job queues + Socket.IO adapter for horizontal scaling
- Paystack — escrow funding (bank transfer, card, mobile money) and payouts
- JWT access/refresh auth, Passport, bcrypt
- Swagger/OpenAPI docs at `/docs`

## Quick start (Docker)

```bash
cp .env.example .env          # fill in real Paystack keys when you have them
docker compose up --build
# migrations run automatically as part of the api container's start command
```

API is then live at `http://localhost:3000`, docs at `http://localhost:3000/docs`.

## Quick start (local Node)

Requires Postgres 15+ and Redis 7+ running locally (or via
`docker compose up -d postgres redis`).

```bash
cp .env.example .env
npm install
npm run migration:run
npm run seed        # creates the same demo users/transactions as the frontend
npm run start:dev
```

## Demo accounts (after `npm run seed`)

All demo accounts share the password `demo1234`:

| Role       | Email                     |
|------------|----------------------------|
| Buyer      | amara@buyer.demo           |
| Seller     | tunde@seller.demo          |
| Logistics  | ops@swiftroute.demo        |
| Support    | ngozi@kudiescrow.demo      |
| Admin      | admin@kudiescrow.demo      |
| Developer  | chidi@developer.demo       |

Four seeded transactions mirror the frontend exactly: one in transit
(`KE-2026-483920`), one in dispute (`KE-2026-119004`), one pending funding
(`KE-2026-720117`), and one fully released (`KE-2026-055881`).

## Architecture notes

- **The escrow state machine is the core of this system.**
  `src/modules/transactions/transaction-state.service.ts` is the *only*
  place `transaction.status` is allowed to change. Every transition is
  validated against an explicit allow-list, runs inside a single Postgres
  transaction alongside any wallet movement and the audit log write, and
  emits a `transaction.status_changed` domain event afterward. Chat system
  messages, websocket broadcasts, and notification fan-out all react to
  that event rather than being called inline — see
  `chat/transaction-chat.listener.ts`, `websockets/realtime.gateway.ts`,
  and `notifications/notifications.service.ts`.
- **Money is never a float.** All monetary columns are `numeric(18,2)`,
  represented as strings in TypeScript, and all arithmetic goes through
  `decimal.js` inside `wallets.service.ts`.
- **Paystack webhook verification is mandatory.** The webhook route reads
  the raw request body (`rawBody: true` in `main.ts`) so the HMAC SHA512
  signature can be checked before any payload is trusted
  (`paystack.service.ts#verifyWebhookSignature`).
- **Circular module dependencies** (Transactions ↔ Logistics, Transactions
  ↔ Payments) are resolved with `forwardRef()` on both the module and
  provider injection sides — this is intentional, not an oversight; the
  escrow engine and the logistics/payment triggers that drive it
  legitimately need each other.
- **Everything financially or procedurally significant is audit-logged** —
  see `common/audit-log.service.ts` and its call sites in the state
  machine and disputes service.

## Testing

```bash
npm test              # unit tests — see transaction-state.service.spec.ts
                       # for full coverage of every legal and illegal
                       # escrow transition
npm run test:e2e       # requires a running Postgres + Redis (docker compose
                       # up -d postgres redis) — walks the HTTP API through
                       # registration, transaction creation, chat, and
                       # dispute handling
```

## What's stubbed vs. production-ready

Built to spec and reasonably production-shaped:
- Escrow state machine, wallet ledger, disputes lifecycle, RBAC, audit log
- Paystack funding + webhook verification
- Logistics checkpoints driving escrow transitions
- Chat, WebSocket rooms (with Redis adapter), developer API keys/webhooks

Left as clearly-marked placeholders (need real credentials/infra to finish,
not architectural gaps):
- **File storage**: chat attachments and proof-of-delivery uploads accept
  the file but don't yet stream to S3 — swap the placeholder in
  `chat.controller.ts` / `logistics.controller.ts` for an actual S3 client
  call using the `S3_*` env vars already wired into config.
- **Notification delivery**: `notifications.processor.ts` logs jobs instead
  of calling SMTP/SMS/push providers — the queue, retry, and backoff
  behavior are real; only the last-mile send is a stub.
- **Webhook delivery to developers**: registration and storage of developer
  webhook subscriptions work; the actual signed HTTP delivery + retry queue
  described in the build prompt (section 11) still needs to be wired the
  same way `notifications.processor.ts` is.
- **2FA**: `auth.service.ts#verifyTwoFactor` accepts any 6-digit code — needs
  a real OTP provider (SMS/email) and Redis-backed code storage.
- Payment provider is Paystack-only for now; `payment-provider.interface.ts`
  is the seam for adding Flutterwave or a crypto settlement rail later
  without touching `TransactionStateService`.

## Environment variables

See `.env.example`. `DATABASE_URL`, `REDIS_URL`, `JWT_ACCESS_SECRET`, and
`JWT_REFRESH_SECRET` are required; everything else has a safe dev default
or is only needed once you wire real Paystack/S3/SMTP credentials.
