import { Injectable, Logger } from '@nestjs/common';
import { InjectQueue } from '@nestjs/bullmq';
import { OnEvent } from '@nestjs/event-emitter';
import { Queue } from 'bullmq';
import { TRANSACTION_EVENTS, TransactionStatusChangedEvent } from '../transactions/events/transaction-events';
import { CHAT_EVENTS } from '../chat/chat.service';
import { ChatMessage, ChatMessageType } from '../chat/entities/chat-message.entity';

export interface NotificationJob {
  userId: string;
  channel: 'email' | 'sms' | 'push' | 'in_app';
  title: string;
  body: string;
}

@Injectable()
export class NotificationsService {
  private readonly logger = new Logger('NotificationsService');

  constructor(@InjectQueue('notifications') private readonly queue: Queue<NotificationJob>) {}

  async notify(job: NotificationJob): Promise<void> {
    await this.queue.add('fan-out', job, {
      attempts: 3,
      backoff: { type: 'exponential', delay: 5000 },
    });
  }

  @OnEvent(TRANSACTION_EVENTS.STATUS_CHANGED)
  async onStatusChanged(event: TransactionStatusChangedEvent) {
    this.logger.log(`Transaction ${event.reference} moved ${event.from} -> ${event.to}`);
    // In production this fans out to the buyer/seller/logistics/support
    // parties on the transaction via the in_app + email + push channels.
    // Left as a log line here since actual delivery needs SMTP/SMS/push
    // credentials which are environment-specific.
  }

  @OnEvent(CHAT_EVENTS.MESSAGE_CREATED)
  async onChatMessage(message: ChatMessage) {
    if (message.type === ChatMessageType.SYSTEM) return;
    this.logger.log(`New chat message on transaction ${message.transactionId}`);
  }
}
