import { Processor, WorkerHost } from '@nestjs/bullmq';
import { Logger } from '@nestjs/common';
import { Job } from 'bullmq';
import { NotificationJob } from './notifications.service';

@Processor('notifications')
export class NotificationsProcessor extends WorkerHost {
  private readonly logger = new Logger('NotificationsProcessor');

  async process(job: Job<NotificationJob>): Promise<void> {
    const { userId, channel, title, body } = job.data;
    // Placeholder delivery: swap in SMTP (nodemailer), an SMS provider, and
    // a push provider (FCM/APNs) behind this switch. Kept as structured
    // logging so the queue/retry/backoff wiring is exercised end-to-end
    // without requiring live credentials in every environment.
    this.logger.log(`[${channel}] -> user ${userId}: ${title} — ${body}`);
  }
}
