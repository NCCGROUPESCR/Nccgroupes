import { Body, Controller, Get, Param, Patch, Query, UseGuards } from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { Roles } from '../../common/decorators/roles.decorator';
import { UserRole } from '../users/entities/user.entity';
import { AdminService } from './admin.service';
import { TransactionStatus } from '../transactions/entities/transaction.entity';

@ApiTags('admin')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, RolesGuard)
@Roles(UserRole.ADMIN)
@Controller('v1/admin')
export class AdminController {
  constructor(private readonly adminService: AdminService) {}

  @Get('transactions')
  transactions(@Query('status') status?: TransactionStatus) {
    return this.adminService.allTransactions(status);
  }

  @Get('users')
  users() {
    return this.adminService.allUsers();
  }

  @Patch('users/:id/verify')
  verify(@Param('id') id: string, @Body('verified') verified: boolean) {
    return this.adminService.verifyBusiness(id, verified);
  }

  @Get('reports/volume')
  volumeReport() {
    return this.adminService.volumeReport();
  }
}
