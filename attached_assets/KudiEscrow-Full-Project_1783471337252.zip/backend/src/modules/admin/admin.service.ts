import { Injectable } from '@nestjs/common';
import { TransactionsService } from '../transactions/transactions.service';
import { UsersService } from '../users/users.service';
import { User } from '../users/entities/user.entity';
import { TransactionStatus } from '../transactions/entities/transaction.entity';

@Injectable()
export class AdminService {
  constructor(
    private readonly transactionsService: TransactionsService,
    private readonly usersService: UsersService,
  ) {}

  async allTransactions(status?: TransactionStatus) {
    // Admin sees every transaction — reuse findForUser's admin branch by
    // passing a synthetic admin-shaped user context isn't ideal, so query
    // directly here instead for clarity.
    return this.transactionsService.findForUser({ role: 'admin' } as User, status);
  }

  async allUsers() {
    return this.usersService.findAll();
  }

  async verifyBusiness(userId: string, verified: boolean) {
    return this.usersService.setBusinessVerified(userId, verified);
  }

  async volumeReport() {
    const txns = await this.transactionsService.findForUser({ role: 'admin' } as User);
    const totalVolume = txns.reduce((sum, t) => sum + Number(t.amount), 0);
    const byStatus = txns.reduce<Record<string, number>>((acc, t) => {
      acc[t.status] = (acc[t.status] || 0) + 1;
      return acc;
    }, {});
    return { totalTransactions: txns.length, totalVolume, byStatus };
  }
}
