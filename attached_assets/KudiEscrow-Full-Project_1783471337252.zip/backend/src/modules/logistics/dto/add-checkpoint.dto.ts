import { IsOptional, IsString, MaxLength } from 'class-validator';

export class AdvanceCheckpointDto {
  @IsOptional()
  @IsString()
  @MaxLength(200)
  note?: string;
}
