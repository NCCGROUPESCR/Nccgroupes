import { Controller, Get, Param, Post, UploadedFile, UseGuards, UseInterceptors } from '@nestjs/common';
import { FileInterceptor } from '@nestjs/platform-express';
import { ApiBearerAuth, ApiConsumes, ApiTags } from '@nestjs/swagger';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { Roles } from '../../common/decorators/roles.decorator';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import { User, UserRole } from '../users/entities/user.entity';
import { LogisticsService } from './logistics.service';
import { TransactionsService } from '../transactions/transactions.service';

@ApiTags('logistics')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, RolesGuard)
@Controller('v1')
export class LogisticsController {
  constructor(
    private readonly logisticsService: LogisticsService,
    private readonly transactionsService: TransactionsService,
  ) {}

  @Get('shipments/:transactionId/tracking')
  getTracking(@Param('transactionId') transactionId: string) {
    return this.logisticsService.getTracking(transactionId);
  }

  @Roles(UserRole.LOGISTICS)
  @Post('shipments/:transactionId/checkpoints')
  async advance(@Param('transactionId') transactionId: string, @CurrentUser() user: User) {
    const txn = await this.transactionsService.findById(transactionId);
    return this.logisticsService.advanceCheckpoint(transactionId, user.id, txn.logisticsId);
  }

  @Roles(UserRole.LOGISTICS)
  @ApiConsumes('multipart/form-data')
  @Post('shipments/:transactionId/proof-of-delivery')
  @UseInterceptors(FileInterceptor('file'))
  async uploadProofOfDelivery(
    @Param('transactionId') transactionId: string,
    @UploadedFile() file: any,
  ) {
    // In production this streams `file.buffer` to the configured S3 bucket
    // and stores the resulting URL against the shipment record. Wired here
    // as a placeholder so the endpoint shape is stable for the frontend.
    return {
      transactionId,
      filename: file?.originalname ?? null,
      size: file?.size ?? null,
      stored: !!file,
    };
  }
}
