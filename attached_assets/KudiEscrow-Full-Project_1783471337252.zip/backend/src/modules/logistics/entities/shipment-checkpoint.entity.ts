import { Column, Entity, PrimaryGeneratedColumn } from 'typeorm';

export enum CheckpointStatus {
  PENDING = 'pending',
  ACTIVE = 'active',
  DONE = 'done',
}

@Entity('shipment_checkpoints')
export class ShipmentCheckpoint {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ type: 'uuid' })
  shipmentId: string;

  @Column()
  label: string;

  @Column({ type: 'enum', enum: CheckpointStatus, default: CheckpointStatus.PENDING })
  status: CheckpointStatus;

  @Column({ type: 'int' })
  sequence: number;

  @Column({ type: 'timestamptz', nullable: true })
  occurredAt: Date | null;
}
