import { Column, Entity, Index, PrimaryGeneratedColumn } from 'typeorm';

export enum ShipmentMode {
  ROAD = 'road',
  AIR = 'air',
  SEA = 'sea',
  NONE = 'none',
}

@Entity('shipments')
export class Shipment {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Index({ unique: true })
  @Column({ type: 'uuid' })
  transactionId: string;

  @Column({ type: 'enum', enum: ShipmentMode, default: ShipmentMode.NONE })
  mode: ShipmentMode;

  @Column({ nullable: true })
  origin: string;

  @Column({ nullable: true })
  destination: string;

  @Column({ type: 'date', nullable: true })
  eta: string | null;

  @Column({ type: 'numeric', precision: 9, scale: 6, nullable: true })
  currentLat: string | null;

  @Column({ type: 'numeric', precision: 9, scale: 6, nullable: true })
  currentLng: string | null;
}
