import { forwardRef, Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Shipment } from './entities/shipment.entity';
import { ShipmentCheckpoint } from './entities/shipment-checkpoint.entity';
import { LogisticsService } from './logistics.service';
import { LogisticsController } from './logistics.controller';
import { TransactionsModule } from '../transactions/transactions.module';

@Module({
  imports: [
    TypeOrmModule.forFeature([Shipment, ShipmentCheckpoint]),
    forwardRef(() => TransactionsModule),
  ],
  providers: [LogisticsService],
  controllers: [LogisticsController],
  exports: [LogisticsService],
})
export class LogisticsModule {}
