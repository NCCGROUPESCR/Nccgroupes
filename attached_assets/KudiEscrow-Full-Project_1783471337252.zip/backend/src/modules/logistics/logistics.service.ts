import { ForbiddenException, Inject, Injectable, NotFoundException, forwardRef } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Shipment, ShipmentMode } from './entities/shipment.entity';
import { CheckpointStatus, ShipmentCheckpoint } from './entities/shipment-checkpoint.entity';
import { Transaction } from '../transactions/entities/transaction.entity';
import { CreateTransactionDto } from '../transactions/dto/create-transaction.dto';
import { TransactionStateService } from '../transactions/transaction-state.service';

const DEFAULT_ROUTE_LABELS: Record<ShipmentMode, string[]> = {
  [ShipmentMode.ROAD]: ['Pickup confirmed', 'Departed origin hub', 'In transit', 'Arrived at destination hub', 'Delivered to buyer'],
  [ShipmentMode.AIR]: ['Pickup confirmed', 'Departed origin airport', 'Customs clearance', 'Arrived at destination airport', 'Delivered to buyer'],
  [ShipmentMode.SEA]: ['Pickup confirmed', 'Loaded at origin port', 'Departed port', 'Customs clearance', 'Delivered to buyer'],
  [ShipmentMode.NONE]: ['Delivered to buyer'],
};

@Injectable()
export class LogisticsService {
  constructor(
    @InjectRepository(Shipment) private readonly shipmentRepo: Repository<Shipment>,
    @InjectRepository(ShipmentCheckpoint) private readonly checkpointRepo: Repository<ShipmentCheckpoint>,
    @Inject(forwardRef(() => TransactionStateService))
    private readonly stateService: TransactionStateService,
  ) {}

  async createShipmentForTransaction(txn: Transaction, dto: CreateTransactionDto): Promise<Shipment> {
    const mode = (dto.mode as ShipmentMode) || ShipmentMode.NONE;
    const shipment = await this.shipmentRepo.save(
      this.shipmentRepo.create({
        transactionId: txn.id,
        mode,
        origin: dto.origin,
        destination: dto.destination,
        eta: dto.eta ?? null,
      }),
    );

    const labels = DEFAULT_ROUTE_LABELS[mode];
    const checkpoints = labels.map((label, i) =>
      this.checkpointRepo.create({
        shipmentId: shipment.id,
        label,
        sequence: i,
        status: CheckpointStatus.PENDING,
      }),
    );
    await this.checkpointRepo.save(checkpoints);
    return shipment;
  }

  async findByTransactionId(transactionId: string): Promise<Shipment> {
    const shipment = await this.shipmentRepo.findOne({ where: { transactionId } });
    if (!shipment) throw new NotFoundException('Shipment not found for this transaction.');
    return shipment;
  }

  async getCheckpoints(shipmentId: string): Promise<ShipmentCheckpoint[]> {
    return this.checkpointRepo.find({ where: { shipmentId }, order: { sequence: 'ASC' } });
  }

  async getTracking(transactionId: string) {
    const shipment = await this.findByTransactionId(transactionId);
    const checkpoints = await this.getCheckpoints(shipment.id);
    return { shipment, checkpoints };
  }

  /**
   * Advances the shipment's active checkpoint to 'done' and activates the
   * next one. The FIRST checkpoint activation is what pushes the escrow
   * transaction from SECURED -> TRANSIT; the LAST checkpoint completing
   * pushes it to DELIVERED.
   */
  async advanceCheckpoint(
    transactionId: string,
    logisticsUserId: string,
    txnLogisticsId: string | null,
  ): Promise<ShipmentCheckpoint[]> {
    if (txnLogisticsId !== logisticsUserId) {
      throw new ForbiddenException('You are not the assigned logistics provider for this transaction.');
    }

    const shipment = await this.findByTransactionId(transactionId);
    const checkpoints = await this.getCheckpoints(shipment.id);

    // First call: activate checkpoint 0 and flip the transaction to TRANSIT.
    const anyActive = checkpoints.find((c) => c.status === CheckpointStatus.ACTIVE);
    if (!anyActive) {
      checkpoints[0].status = CheckpointStatus.ACTIVE;
      await this.checkpointRepo.save(checkpoints[0]);
      await this.stateService.markInTransit(transactionId, logisticsUserId);
      return this.getCheckpoints(shipment.id);
    }

    anyActive.status = CheckpointStatus.DONE;
    anyActive.occurredAt = new Date();
    await this.checkpointRepo.save(anyActive);

    const next = checkpoints.find((c) => c.sequence === anyActive.sequence + 1);
    if (next) {
      next.status = CheckpointStatus.ACTIVE;
      await this.checkpointRepo.save(next);
    } else {
      // Last checkpoint just completed.
      await this.stateService.markDelivered(transactionId, logisticsUserId);
    }

    return this.getCheckpoints(shipment.id);
  }
}
