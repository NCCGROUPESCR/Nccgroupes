import { IsIn, IsNotEmpty, IsNumberString, IsOptional, IsString, IsUUID, MaxLength } from 'class-validator';

export class CreateTransactionDto {
  @IsString()
  @MaxLength(200)
  title: string;

  @IsOptional()
  @IsString()
  @MaxLength(80)
  category?: string;

  @IsUUID()
  sellerId: string;

  @IsOptional()
  @IsUUID()
  logisticsId?: string;

  @IsNumberString()
  amount: string;

  @IsOptional()
  @IsString()
  currency?: string;

  @IsOptional()
  @IsString()
  @MaxLength(500)
  releaseConditions?: string;

  @IsOptional()
  @IsIn(['road', 'air', 'sea', 'none'])
  mode?: 'road' | 'air' | 'sea' | 'none';

  @IsOptional()
  @IsString()
  origin?: string;

  @IsOptional()
  @IsString()
  destination?: string;

  @IsOptional()
  @IsNotEmpty()
  eta?: string;
}
