import { Body, Controller, Get, Inject, Param, Post, Query, UseGuards, forwardRef } from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { Roles } from '../../common/decorators/roles.decorator';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import { User, UserRole } from '../users/entities/user.entity';
import { TransactionsService } from './transactions.service';
import { CreateTransactionDto } from './dto/create-transaction.dto';
import { TransactionStatus } from './entities/transaction.entity';
import { LogisticsService } from '../logistics/logistics.service';
import { PaymentsService } from '../payments/payments.service';

@ApiTags('transactions')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, RolesGuard)
@Controller('v1/transactions')
export class TransactionsController {
  constructor(
    private readonly transactionsService: TransactionsService,
    private readonly logisticsService: LogisticsService,
    @Inject(forwardRef(() => PaymentsService))
    private readonly paymentsService: PaymentsService,
  ) {}

  @Roles(UserRole.BUYER)
  @Post()
  async create(@CurrentUser() user: User, @Body() dto: CreateTransactionDto) {
    const txn = await this.transactionsService.create(user.id, dto);
    // Creates the shipment record (or a no-shipping placeholder) alongside the transaction.
    await this.logisticsService.createShipmentForTransaction(txn, dto);
    return txn;
  }

  @Get()
  findAll(@CurrentUser() user: User, @Query('status') status?: TransactionStatus) {
    return this.transactionsService.findForUser(user, status);
  }

  @Get(':id')
  findOne(@Param('id') id: string) {
    return this.transactionsService.findById(id);
  }

  @Roles(UserRole.BUYER)
  @Post(':id/fund')
  fund(@Param('id') id: string, @CurrentUser() user: User) {
    return this.paymentsService.initializeFunding(id, user.id);
  }

  @Roles(UserRole.BUYER)
  @Post(':id/confirm-delivery')
  confirmDelivery(@Param('id') id: string, @CurrentUser() user: User) {
    return this.transactionsService.confirmDelivery(id, user.id);
  }

  @Roles(UserRole.BUYER)
  @Post(':id/release')
  release(@Param('id') id: string, @CurrentUser() user: User) {
    return this.transactionsService.release(id, user.id);
  }

  @Roles(UserRole.BUYER)
  @Post(':id/cancel')
  cancel(@Param('id') id: string, @CurrentUser() user: User) {
    return this.transactionsService.cancel(id, user.id);
  }
}
