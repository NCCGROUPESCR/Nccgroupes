import { ForbiddenException, Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { randomInt } from 'crypto';
import { Transaction, TransactionStatus } from './entities/transaction.entity';
import { CreateTransactionDto } from './dto/create-transaction.dto';
import { TransactionStateService } from './transaction-state.service';
import { User, UserRole } from '../users/entities/user.entity';

@Injectable()
export class TransactionsService {
  constructor(
    @InjectRepository(Transaction) private readonly txnRepo: Repository<Transaction>,
    private readonly stateService: TransactionStateService,
  ) {}

  async create(buyerId: string, dto: CreateTransactionDto): Promise<Transaction> {
    const txn = this.txnRepo.create({
      reference: this.generateReference(),
      title: dto.title,
      category: dto.category,
      buyerId,
      sellerId: dto.sellerId,
      logisticsId: dto.logisticsId ?? null,
      amount: dto.amount,
      currency: dto.currency ?? 'NGN',
      releaseConditions: dto.releaseConditions ?? 'Funds release on confirmed delivery.',
      status: TransactionStatus.PENDING,
    });
    return this.txnRepo.save(txn);
  }

  async findById(id: string): Promise<Transaction> {
    const txn = await this.txnRepo.findOne({ where: { id } });
    if (!txn) throw new NotFoundException('Transaction not found.');
    return txn;
  }

  async findByReference(reference: string): Promise<Transaction> {
    const txn = await this.txnRepo.findOne({ where: { reference } });
    if (!txn) throw new NotFoundException('Transaction not found.');
    return txn;
  }

  /** Role-scoped list: buyers/sellers/logistics see only their own transactions; support/admin see everything. */
  async findForUser(user: User, status?: TransactionStatus): Promise<Transaction[]> {
    const qb = this.txnRepo.createQueryBuilder('t').orderBy('t.createdAt', 'DESC');

    if (user.role === UserRole.BUYER) qb.andWhere('t.buyerId = :id', { id: user.id });
    else if (user.role === UserRole.SELLER) qb.andWhere('t.sellerId = :id', { id: user.id });
    else if (user.role === UserRole.LOGISTICS) qb.andWhere('t.logisticsId = :id', { id: user.id });
    else if (![UserRole.SUPPORT, UserRole.ADMIN].includes(user.role)) {
      throw new ForbiddenException('Your role cannot list transactions.');
    }

    if (status) qb.andWhere('t.status = :status', { status });
    return qb.getMany();
  }

  private assertParty(txn: Transaction, userId: string): void {
    if (txn.buyerId !== userId && txn.sellerId !== userId && txn.logisticsId !== userId) {
      throw new ForbiddenException('You are not a party to this transaction.');
    }
  }

  async confirmDelivery(id: string, userId: string): Promise<Transaction> {
    const txn = await this.findById(id);
    if (txn.buyerId !== userId) throw new ForbiddenException('Only the buyer can confirm delivery.');
    return this.stateService.markDelivered(id, userId);
  }

  async release(id: string, userId: string): Promise<Transaction> {
    const txn = await this.findById(id);
    if (txn.buyerId !== userId) throw new ForbiddenException('Only the buyer can release escrow funds.');
    return this.stateService.releaseFull(id, userId);
  }

  async cancel(id: string, userId: string): Promise<Transaction> {
    const txn = await this.findById(id);
    if (txn.buyerId !== userId) throw new ForbiddenException('Only the buyer can cancel this transaction.');
    return this.stateService.cancel(id, userId);
  }

  private generateReference(): string {
    const year = new Date().getFullYear();
    const suffix = randomInt(100000, 999999);
    return `KE-${year}-${suffix}`;
  }
}
