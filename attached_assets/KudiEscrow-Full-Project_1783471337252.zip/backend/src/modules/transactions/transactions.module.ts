import { forwardRef, Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Transaction } from './entities/transaction.entity';
import { TransactionsService } from './transactions.service';
import { TransactionStateService } from './transaction-state.service';
import { TransactionsController } from './transactions.controller';
import { WalletsModule } from '../wallets/wallets.module';
import { CommonModule } from '../../common/common.module';
import { LogisticsModule } from '../logistics/logistics.module';
import { PaymentsModule } from '../payments/payments.module';

@Module({
  imports: [
    TypeOrmModule.forFeature([Transaction]),
    WalletsModule,
    CommonModule,
    forwardRef(() => LogisticsModule),
    forwardRef(() => PaymentsModule),
  ],
  providers: [TransactionsService, TransactionStateService],
  controllers: [TransactionsController],
  exports: [TransactionsService, TransactionStateService],
})
export class TransactionsModule {}
