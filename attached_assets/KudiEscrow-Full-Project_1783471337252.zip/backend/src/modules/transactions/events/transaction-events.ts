import { TransactionStatus } from '../entities/transaction.entity';

export const TRANSACTION_EVENTS = {
  STATUS_CHANGED: 'transaction.status_changed',
  SYSTEM_MESSAGE: 'transaction.system_message',
} as const;

export interface TransactionStatusChangedEvent {
  transactionId: string;
  reference: string;
  from: TransactionStatus;
  to: TransactionStatus;
  actorId: string | null;
}

export interface TransactionSystemMessageEvent {
  transactionId: string;
  text: string;
}
