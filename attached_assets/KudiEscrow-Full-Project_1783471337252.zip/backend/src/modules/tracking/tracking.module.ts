import { Module } from '@nestjs/common';
import { TrackingController } from './tracking.controller';
import { TransactionsModule } from '../transactions/transactions.module';
import { LogisticsModule } from '../logistics/logistics.module';

@Module({
  imports: [TransactionsModule, LogisticsModule],
  controllers: [TrackingController],
})
export class TrackingModule {}
