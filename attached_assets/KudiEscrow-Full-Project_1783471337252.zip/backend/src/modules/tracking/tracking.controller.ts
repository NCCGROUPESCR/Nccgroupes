import { Controller, Get, Param } from '@nestjs/common';
import { ApiTags } from '@nestjs/swagger';
import { TransactionsService } from '../transactions/transactions.service';
import { LogisticsService } from '../logistics/logistics.service';

@ApiTags('tracking')
@Controller('v1/tracking')
export class TrackingController {
  constructor(
    private readonly transactionsService: TransactionsService,
    private readonly logisticsService: LogisticsService,
  ) {}

  /** Public tracking lookup by human-friendly reference, e.g. KE-2026-483920. */
  @Get(':reference')
  async trackByReference(@Param('reference') reference: string) {
    const txn = await this.transactionsService.findByReference(reference);
    const tracking = await this.logisticsService.getTracking(txn.id);
    return {
      reference: txn.reference,
      title: txn.title,
      status: txn.status,
      ...tracking,
    };
  }
}
