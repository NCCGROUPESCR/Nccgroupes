import { Injectable } from '@nestjs/common';
import { OnEvent } from '@nestjs/event-emitter';
import { ChatService } from './chat.service';
import { TRANSACTION_EVENTS, TransactionStatusChangedEvent } from '../transactions/events/transaction-events';
import { TransactionStatus } from '../transactions/entities/transaction.entity';

const MESSAGES: Partial<Record<TransactionStatus, string>> = {
  [TransactionStatus.SECURED]: 'Buyer funded escrow. Funds are held securely until delivery is confirmed.',
  [TransactionStatus.TRANSIT]: 'Shipment is now in transit.',
  [TransactionStatus.DELIVERED]: 'Delivery confirmed. Awaiting fund release.',
  [TransactionStatus.DISPUTE]: 'Dispute opened. Escrow funds are frozen. Support will join this conversation shortly.',
  [TransactionStatus.RELEASED]: 'Escrow released to seller. Transaction complete.',
  [TransactionStatus.REFUNDED]: 'Escrow refunded in full to buyer.',
  [TransactionStatus.CANCELLED]: 'Transaction cancelled before funding.',
};

@Injectable()
export class TransactionChatListener {
  constructor(private readonly chatService: ChatService) {}

  @OnEvent(TRANSACTION_EVENTS.STATUS_CHANGED)
  async handleStatusChanged(event: TransactionStatusChangedEvent) {
    const text = MESSAGES[event.to];
    if (text) {
      await this.chatService.postSystemMessage(event.transactionId, text);
    }
  }
}
