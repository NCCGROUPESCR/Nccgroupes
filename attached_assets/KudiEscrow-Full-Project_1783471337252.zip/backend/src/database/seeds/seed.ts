import 'reflect-metadata';
import * as bcrypt from 'bcrypt';
import dataSource from '../data-source';
import { User, UserRole } from '../../modules/users/entities/user.entity';
import { Wallet } from '../../modules/wallets/entities/wallet.entity';
import { Transaction, TransactionStatus } from '../../modules/transactions/entities/transaction.entity';
import { Shipment, ShipmentMode } from '../../modules/logistics/entities/shipment.entity';
import { CheckpointStatus, ShipmentCheckpoint } from '../../modules/logistics/entities/shipment-checkpoint.entity';
import { ChatMessage, ChatMessageType } from '../../modules/chat/entities/chat-message.entity';
import { Dispute, DisputeStatus } from '../../modules/disputes/entities/dispute.entity';

async function seed() {
  await dataSource.initialize();
  console.log('Connected. Seeding KudiEscrow demo data...');

  const passwordHash = await bcrypt.hash('demo1234', 12);
  const userRepo = dataSource.getRepository(User);

  const existing = await userRepo.findOne({ where: { email: 'amara@buyer.demo' } });
  if (existing) {
    console.log('Demo data already present — skipping. Drop the database and re-run migrations to reseed.');
    await dataSource.destroy();
    return;
  }

  const [buyer, seller, logistics, support, admin, developer] = await userRepo.save([
    userRepo.create({ name: 'Amara Chukwu', email: 'amara@buyer.demo', passwordHash, role: UserRole.BUYER, trustScore: 96 }),
    userRepo.create({ name: 'Tunde Okafor — Okafor Textiles Ltd', email: 'tunde@seller.demo', passwordHash, role: UserRole.SELLER, trustScore: 88, businessVerified: true }),
    userRepo.create({ name: 'SwiftRoute Logistics', email: 'ops@swiftroute.demo', passwordHash, role: UserRole.LOGISTICS, trustScore: 91 }),
    userRepo.create({ name: 'Ngozi Bello', email: 'ngozi@kudiescrow.demo', passwordHash, role: UserRole.SUPPORT }),
    userRepo.create({ name: 'Platform Admin', email: 'admin@kudiescrow.demo', passwordHash, role: UserRole.ADMIN }),
    userRepo.create({ name: 'Chidi Obi', email: 'chidi@developer.demo', passwordHash, role: UserRole.DEVELOPER }),
  ]);

  const walletRepo = dataSource.getRepository(Wallet);
  await walletRepo.save([
    walletRepo.create({ userId: buyer.id, currency: 'NGN', availableBalance: '2450000', escrowBalance: '0', pendingBalance: '0' }),
    walletRepo.create({ userId: seller.id, currency: 'NGN', availableBalance: '1180000', escrowBalance: '0', pendingBalance: '0' }),
  ]);

  const txnRepo = dataSource.getRepository(Transaction);
  const shipmentRepo = dataSource.getRepository(Shipment);
  const checkpointRepo = dataSource.getRepository(ShipmentCheckpoint);
  const chatRepo = dataSource.getRepository(ChatMessage);
  const disputeRepo = dataSource.getRepository(Dispute);

  // --- Transaction 1: in transit ---
  const t1 = await txnRepo.save(
    txnRepo.create({
      reference: 'KE-2026-483920',
      title: 'Industrial Sewing Machines (x12) — Lagos to Accra',
      category: 'Manufacturing Equipment',
      buyerId: buyer.id,
      sellerId: seller.id,
      logisticsId: logistics.id,
      amount: '4820000',
      currency: 'NGN',
      status: TransactionStatus.TRANSIT,
      releaseConditions: 'Funds release on confirmed delivery + 48hr buyer inspection window.',
      escrowFundedAt: new Date('2026-06-18T09:20:00Z'),
    }),
  );
  const s1 = await shipmentRepo.save(
    shipmentRepo.create({ transactionId: t1.id, mode: ShipmentMode.ROAD, origin: 'Lagos, Nigeria', destination: 'Accra, Ghana', eta: '2026-07-09' }),
  );
  await checkpointRepo.save([
    checkpointRepo.create({ shipmentId: s1.id, label: 'Pickup confirmed — Lagos warehouse', status: CheckpointStatus.DONE, sequence: 0, occurredAt: new Date('2026-06-19T08:00:00Z') }),
    checkpointRepo.create({ shipmentId: s1.id, label: 'Departed origin hub', status: CheckpointStatus.DONE, sequence: 1, occurredAt: new Date('2026-06-19T14:30:00Z') }),
    checkpointRepo.create({ shipmentId: s1.id, label: 'Customs clearance — Seme border', status: CheckpointStatus.DONE, sequence: 2, occurredAt: new Date('2026-06-21T11:00:00Z') }),
    checkpointRepo.create({ shipmentId: s1.id, label: 'In transit — Accra corridor', status: CheckpointStatus.ACTIVE, sequence: 3 }),
    checkpointRepo.create({ shipmentId: s1.id, label: 'Arrival at destination hub', status: CheckpointStatus.PENDING, sequence: 4 }),
    checkpointRepo.create({ shipmentId: s1.id, label: 'Delivered to buyer', status: CheckpointStatus.PENDING, sequence: 5 }),
  ]);
  await chatRepo.save([
    chatRepo.create({ transactionId: t1.id, senderId: null, type: ChatMessageType.SYSTEM, body: 'Transaction created. Escrow reference KE-2026-483920.' }),
    chatRepo.create({ transactionId: t1.id, senderId: buyer.id, type: ChatMessageType.TEXT, body: 'Funds are in escrow. Please confirm pickup window with SwiftRoute.' }),
    chatRepo.create({ transactionId: t1.id, senderId: seller.id, type: ChatMessageType.TEXT, body: 'Confirmed — pickup scheduled for the 19th, crates are palletized and ready.' }),
    chatRepo.create({ transactionId: t1.id, senderId: logistics.id, type: ChatMessageType.TEXT, body: 'Driver assigned. ETA to Accra hub is July 9th, tracking is live on your dashboard.' }),
  ]);

  // --- Transaction 2: in dispute ---
  const t2 = await txnRepo.save(
    txnRepo.create({
      reference: 'KE-2026-119004',
      title: 'Handmade Ankara Fabric Bundle (200 yards)',
      category: 'Textiles',
      buyerId: buyer.id,
      sellerId: seller.id,
      logisticsId: logistics.id,
      amount: '610000',
      currency: 'NGN',
      status: TransactionStatus.DISPUTE,
      releaseConditions: 'Funds release on confirmed delivery matching listed specification.',
      escrowFundedAt: new Date('2026-06-24T13:05:00Z'),
    }),
  );
  const s2 = await shipmentRepo.save(
    shipmentRepo.create({ transactionId: t2.id, mode: ShipmentMode.ROAD, origin: 'Abeokuta, Nigeria', destination: 'Lagos, Nigeria', eta: '2026-06-27' }),
  );
  await checkpointRepo.save([
    checkpointRepo.create({ shipmentId: s2.id, label: 'Pickup confirmed', status: CheckpointStatus.DONE, sequence: 0, occurredAt: new Date('2026-06-25T09:00:00Z') }),
    checkpointRepo.create({ shipmentId: s2.id, label: 'Delivered to buyer', status: CheckpointStatus.DONE, sequence: 1, occurredAt: new Date('2026-06-27T15:40:00Z') }),
  ]);
  await chatRepo.save([
    chatRepo.create({ transactionId: t2.id, senderId: null, type: ChatMessageType.SYSTEM, body: 'Transaction created. Escrow reference KE-2026-119004.' }),
    chatRepo.create({ transactionId: t2.id, senderId: buyer.id, type: ChatMessageType.TEXT, body: 'Package arrived but the fabric colour and weight do not match the listing photos.' }),
    chatRepo.create({ transactionId: t2.id, senderId: seller.id, type: ChatMessageType.TEXT, body: 'That is the exact batch shown, dye lots can vary slightly but it is the same grade.' }),
    chatRepo.create({ transactionId: t2.id, senderId: buyer.id, type: ChatMessageType.TEXT, body: 'I would like support to review before funds are released.' }),
    chatRepo.create({ transactionId: t2.id, senderId: null, type: ChatMessageType.SYSTEM, body: 'Dispute opened by buyer. Escrow funds frozen. Support has joined this conversation.' }),
    chatRepo.create({ transactionId: t2.id, senderId: support.id, type: ChatMessageType.TEXT, body: 'Thanks both — I have frozen the release. Buyer, please upload photos of the received fabric next to the original listing for comparison.' }),
  ]);
  await disputeRepo.save(
    disputeRepo.create({
      transactionId: t2.id,
      openedBy: buyer.id,
      reason: 'Item does not match listing description',
      status: DisputeStatus.INVESTIGATING,
      assignedAgentId: support.id,
    }),
  );

  // --- Transaction 3: pending funding ---
  const t3 = await txnRepo.save(
    txnRepo.create({
      reference: 'KE-2026-720117',
      title: 'Refurbished MacBook Pro 14" (x5 units)',
      category: 'Electronics',
      buyerId: buyer.id,
      sellerId: seller.id,
      logisticsId: logistics.id,
      amount: '3150000',
      currency: 'NGN',
      status: TransactionStatus.PENDING,
      releaseConditions: 'Funds release on confirmed delivery + 24hr inspection window.',
    }),
  );
  const s3 = await shipmentRepo.save(
    shipmentRepo.create({ transactionId: t3.id, mode: ShipmentMode.AIR, origin: 'Lagos, Nigeria', destination: 'Nairobi, Kenya', eta: '2026-07-14' }),
  );
  await checkpointRepo.save([
    checkpointRepo.create({ shipmentId: s3.id, label: 'Awaiting escrow funding', status: CheckpointStatus.ACTIVE, sequence: 0 }),
    checkpointRepo.create({ shipmentId: s3.id, label: 'Pickup request', status: CheckpointStatus.PENDING, sequence: 1 }),
    checkpointRepo.create({ shipmentId: s3.id, label: 'Departure', status: CheckpointStatus.PENDING, sequence: 2 }),
    checkpointRepo.create({ shipmentId: s3.id, label: 'Customs clearance', status: CheckpointStatus.PENDING, sequence: 3 }),
    checkpointRepo.create({ shipmentId: s3.id, label: 'Delivered', status: CheckpointStatus.PENDING, sequence: 4 }),
  ]);
  await chatRepo.save([
    chatRepo.create({ transactionId: t3.id, senderId: null, type: ChatMessageType.SYSTEM, body: 'Transaction created. Awaiting buyer to fund escrow.' }),
  ]);

  // --- Transaction 4: fully released ---
  const t4 = await txnRepo.save(
    txnRepo.create({
      reference: 'KE-2026-055881',
      title: 'Cocoa Beans — Bulk Export Lot (2 tonnes)',
      category: 'Agriculture Export',
      buyerId: buyer.id,
      sellerId: seller.id,
      logisticsId: logistics.id,
      amount: '9200000',
      currency: 'NGN',
      status: TransactionStatus.RELEASED,
      releaseConditions: 'Funds release on confirmed delivery.',
      escrowFundedAt: new Date('2026-05-30T08:10:00Z'),
      escrowReleasedAt: new Date('2026-06-10T09:00:00Z'),
    }),
  );
  const s4 = await shipmentRepo.save(
    shipmentRepo.create({ transactionId: t4.id, mode: ShipmentMode.SEA, origin: 'Lagos Port, Nigeria', destination: 'Rotterdam, Netherlands', eta: '2026-06-09' }),
  );
  await checkpointRepo.save([
    checkpointRepo.create({ shipmentId: s4.id, label: 'Pickup confirmed', status: CheckpointStatus.DONE, sequence: 0, occurredAt: new Date('2026-05-31T08:00:00Z') }),
    checkpointRepo.create({ shipmentId: s4.id, label: 'Loaded — Lagos Port', status: CheckpointStatus.DONE, sequence: 1, occurredAt: new Date('2026-06-01T12:00:00Z') }),
    checkpointRepo.create({ shipmentId: s4.id, label: 'Departed port', status: CheckpointStatus.DONE, sequence: 2, occurredAt: new Date('2026-06-02T06:00:00Z') }),
    checkpointRepo.create({ shipmentId: s4.id, label: 'Customs clearance — Rotterdam', status: CheckpointStatus.DONE, sequence: 3, occurredAt: new Date('2026-06-08T09:00:00Z') }),
    checkpointRepo.create({ shipmentId: s4.id, label: 'Delivered to buyer', status: CheckpointStatus.DONE, sequence: 4, occurredAt: new Date('2026-06-09T15:00:00Z') }),
  ]);
  await chatRepo.save([
    chatRepo.create({ transactionId: t4.id, senderId: null, type: ChatMessageType.SYSTEM, body: 'Transaction created. Escrow reference KE-2026-055881.' }),
    chatRepo.create({ transactionId: t4.id, senderId: buyer.id, type: ChatMessageType.TEXT, body: 'Delivery confirmed, quality matches sample. Releasing funds.' }),
    chatRepo.create({ transactionId: t4.id, senderId: null, type: ChatMessageType.SYSTEM, body: 'Escrow released to seller. Transaction complete.' }),
  ]);

  console.log('Seed complete:');
  console.log('  buyer:      amara@buyer.demo / demo1234');
  console.log('  seller:     tunde@seller.demo / demo1234');
  console.log('  logistics:  ops@swiftroute.demo / demo1234');
  console.log('  support:    ngozi@kudiescrow.demo / demo1234');
  console.log('  admin:      admin@kudiescrow.demo / demo1234');
  console.log('  developer:  chidi@developer.demo / demo1234');

  await dataSource.destroy();
}

seed().catch((err) => {
  console.error('Seed failed:', err);
  process.exit(1);
});
