# KudiEscrow — Full Project

Secure escrow, logistics, and trade-assurance platform. This package
contains both halves of the build:

- **frontend/** — static HTML/CSS/JS demo (no build step), backed by a
  localStorage mock data layer. Deploy as-is to Netlify, or open
  `index.html` directly.
- **backend/** — production NestJS API (PostgreSQL + Redis + Paystack +
  Socket.IO) that implements the same data shapes the frontend mocks.
  See `backend/README.md` for setup, and
  `backend/README.md#whats-stubbed-vs-production-ready` for exactly what's
  wired end-to-end versus placeholder.

## Wiring them together

The frontend currently talks to `js/store.js`, a localStorage-backed mock
of the API. To connect it to the real backend:

1. Run the backend (`cd backend && docker compose up --build`, or see
   the local Node instructions in `backend/README.md`).
2. Replace the functions in `frontend/js/store.js` (e.g. `ke_getTxns`,
   `ke_createTxn`, `ke_fundEscrow`) with `fetch()` calls to the matching
   endpoint (e.g. `GET /v1/transactions`, `POST /v1/transactions`,
   `POST /v1/transactions/:id/fund`) — the function names and data shapes
   were designed to line up 1:1 with the backend's REST surface.
3. Swap the login/signup pages to store the JWT `accessToken` returned by
   `/v1/auth/login` instead of just a user id, and send it as a
   `Authorization: Bearer` header on every subsequent request.
4. For live chat/tracking updates, connect a Socket.IO client to
   `/realtime` (see `backend/src/modules/websockets/realtime.gateway.ts`
   for the room/event names) instead of re-rendering from localStorage.

Both sides use the same demo accounts and transaction references
(`KE-2026-483920`, etc.) so you can sanity-check the wiring transaction by
transaction as you go.
